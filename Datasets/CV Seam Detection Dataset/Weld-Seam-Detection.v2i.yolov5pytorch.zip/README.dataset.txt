# Weld-Seam-Detection > 2025-05-21 11:50am
https://universe.roboflow.com/seam-2fhuj/weld-seam-detection-7mhq4

Provided by a Roboflow user
License: CC BY 4.0

